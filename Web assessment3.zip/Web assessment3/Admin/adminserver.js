const express = require("express")
const path = require("path")

const app = express()

app.use(express.static("Admin"))
app.use(express.json())

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname + "/Home.html"));
});
app.get("/insert", (req, res) => {
    res.sendFile(path.join(__dirname + "/Insert.html"));
});
app.get("/Change", (req, res) => {
    res.sendFile(path.join(__dirname + "/Change.html"));
});
app.listen(8081, () => {
    console.log("adminserver is running at 127.0.0.1:8081")
})