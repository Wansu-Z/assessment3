
const express = require("express");
const connection = require("./crowdfunding_db");


connection.connect();

const router = express.Router();
//GET
router.get("/", (req, res) => {
    connection.query("select FUNDRAISER_ID,ORGANIZER,CAPTION,TARGET_FUNDING,CURRENT_FUNDING,CITY,ACTIVE,NAME from fundraiser inner join category on fundraiser.CATEGORY_ID = category.CATEGORY_ID", (err, result) => {
        if (err) {
            console.error("Error while retrieve the data");
        } else {
            res.send(result);
        }
    })
})

router.get("/details/:fundraiser_id", (req, res) => {
    connection.query("select * from fundraiser inner join category on fundraiser.category_id = category.category_id where fundraiser.FUNDRAISER_ID=" + req.params.fundraiser_id, (err, result) => {
        if (err) {
            console.error("Error while retrieve the data");
        } else {
            res.send(result);
        }
    })
});
//POST
router.post("/", (req, res) => {
    console.log(req.body);
    var ID = req.body.ID;
    var Organizer = req.body.Organizer;
    var Caption = req.body.Caption;
    var Target = req.body.Target;
    var Current = req.body.Current;
    var City = req.body.City;
    var Active = req.body.Active;
    var Category = req.body.Category;
    var cid = 0;
    if (Category == "Donation-based crowdfunding") {
        cid = 1;
    } else if (Category == "Reward-based crowdfunding") {
        cid = 2;
    } else if (Category == "Equity-based crowdfunding") {
        cid = 3;
    } else if (Category == "Debt-based crowdfunding") {
        cid = 4;
    } else if (Category == "Royalty-based crowdfunding") {
        cid = 5;
    }
    connection.query("INSERT INTO fundraiser VALUES(" + ID + ",'" + Organizer + "','" + Caption + "'," + Target + "," + Current + ",'" + City + "','" + Active + "'," + cid + ")",
        (err, result) => {
            if (err) {
                console.error("Error while retrieve the data" + err);
            } else {
                res.send({ insert: "success" });
            }
        })
})
//PUT
router.put("/", (req, res) => {
    console.log(req.body);
    var ID = req.body.ID;
    var Organizer = req.body.Organizer;
    var Caption = req.body.Caption;
    var Target = req.body.Target;
    var Current = req.body.Current;
    var City = req.body.City;
    var Active = req.body.Active;
    var Category = req.body.Category;
    var cid = 0;
    if (Category == "Donation-based crowdfunding") {
        cid = 1;
    } else if (Category == "Reward-based crowdfunding") {
        cid = 2;
    } else if (Category == "Equity-based crowdfunding") {
        cid = 3;
    } else if (Category == "Debt-based crowdfunding") {
        cid = 4;
    } else if (Category == "Royalty-based crowdfunding") {
        cid = 5;
    }
    connection.query("UPDATE fundraiser SET ORGANIZER=" + Organizer + ",CAPTION=" + Caption + ",TARGET_FUNDING =" + Target + ",CURRENT_FUNDING=" + Current + ",CITY = " + City + ",ACTIVE = " + Active + ",CATEGORY_ID =" + cid + "WHERE FUNDRAISER_ID =" + ID,
        (err, result) => {
            if (err) {
                console.error("Error while retrieve the data" + err);
            } else {
                res.send({ update: "success" });
            }
        })
})
//DELETE
router.delete("/:id", (req, res) => {
    console.log(req.params.id)
    connection.query("delete from fundraiser where FUNDRAISER_ID=" + req.params.id, (err, records, fields) => {
        if (err) {
            console.error("Error while deleting the data");
        } else {
            res.send({ delete: "Delete Sucess" });
        }
    })
})

module.exports = router;